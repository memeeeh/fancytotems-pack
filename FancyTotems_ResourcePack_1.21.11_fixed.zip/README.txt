FancyTotems Resource Pack (Minecraft 1.21.11)

This pack uses the 1.21.11 item declaration system:
- assets/minecraft/items/totem_of_undying.json

CustomModelData values:
1001 = Bloodrage
1002 = Void
1003 = Wrath
1101 = Bloodrage Corrupted
1102 = Void Corrupted
1103 = Wrath Corrupted

Install:
Zip the contents so that pack.mcmeta and assets/ are at the root of the zip.
