# FancyTotems Resource Pack

CustomModelData mapping:
- 1001 = Bloodrage Totem
- 1002 = Void Totem
- 1003 = Wrath Totem
- 1101 = Bloodrage Totem (Corrupted)
- 1102 = Void Totem (Corrupted)
- 1103 = Wrath Totem (Corrupted)

Suggested plugin logic:
- Normal tier totems use 1001/1002/1003
- When a totem enters corrupted state at 3/1 uses, switch to 1101/1102/1103

Files included:
- pack.mcmeta
- model overrides for totem_of_undying
- 6 texture PNGs
- 6 model JSON files
